# EvoViM

EvoViM evolves the Python memory program of a multimodal agent. During play, the program selects what to store and which evidence to recall. Between generations, a revision model edits the program using episode traces. This release includes the starting scaffold and the **18 programs selected for the paper’s held-out evaluations**.

## Run an evolved program offline

From the repository root on macOS or Linux, create a Python 3.10+ environment. Python 3.10 users can add `-c examples/constraints-py310.txt` to the install command to use the tested dependency versions.

```sh
python3 -m venv .venv
. .venv/bin/activate
python -m pip install .
evovim demo --cards
```

The demo runs offline on a four-card board. A scripted player flips three cards, queries the released GPT Card Matching program, recalls its saved image and flips the mate it found. Expect `recalled_pair` to be `["bA", "aA"]`, four actions, one valid image request and a score of `1.0`. Add `--output runs/cards` to keep the episode trace. The paper task uses a 12×12 board.

```sh
evovim programs
evovim export gpt/card-matching ./card-program
```

Export writes a standalone, hash-verified directory containing `candidate.py`, its imports and its original file manifest. Use a fresh destination. Program IDs combine one of `gpt`, `haiku` and `qwen` with one of `card-matching`, `dmv-hard`, `minecraft-gallery`, `poster-maze`, `tetris` and `pac-man`. The catalog records the model, source run, selected revision, SHA-256 and per-seed held-out scores. Files identical to the starting scaffold are shared in the distribution. [Program catalog](visual_rsi/programs/catalog.json)

## Evaluate on the original task

Install the chosen benchmark’s pinned assets, then test its real reset, observation, candidate worker and first action. This command uses a scripted model and makes no API requests. [Benchmark setup](examples/benchmarks.md)

```sh
evovim evaluate gpt/card-matching --smoke --output runs/card-smoke
```

For a full episode, supply an image-capable model and its credential. The program ID selects the memory code and task. The model ID selects the service that makes decisions during this run. Use `OPENAI_API_KEY` for GPT or Qwen Chat Completions and `ANTHROPIC_API_KEY` for Haiku Messages. Set `EVOVIM_EPISODE_BASE_URL` to use your own compatible endpoint.

```sh
evovim evaluate gpt/card-matching --model "$EVOVIM_EPISODE_MODEL" \
    --seed 47 --output runs/card-47
```

Each invocation runs one seed and writes to a new directory. The default is the task’s first held-out seed. The trace includes the task and model settings, observations, actions, model exchanges and score. For a held-out mean, run the listed seeds in separate directories and average their final scores. The released catalog contains historical measurements. Scores from a new model service can differ. [Task IDs, horizons and seeds](visual_rsi/benchmarks/tasks.json)

## Evolve a new program

The included GridMemory manifest starts from the visual scaffold and runs one development seed and one generation. It uses a multimodal Chat Completions endpoint, a signed-in Codex CLI for revisions and macOS Seatbelt for worker isolation. Set `OPENAI_API_KEY` and your actual model ID before running.

```sh
export EVOVIM_EPISODE_MODEL="your-vision-model-id"
export EVOVIM_META_WORKSPACE="$(mktemp -d /tmp/evovim-workspace.XXXXXX)"
evovim run --manifest examples/gridmemory.yaml --run-root runs/grid
evovim verify --run-root runs/grid
```

Keep the workspace and rerun the same command and manifest to resume. The retained program is in `runs/grid/environments/gridmemory/lines/M/parent/`. To exercise it offline, run `evovim demo --bundle runs/grid/environments/gridmemory/lines/M/parent`. The offline demos and standalone evaluations use ordinary subprocesses and run trusted program code. [GridMemory manifest](examples/gridmemory.yaml)

## Use another environment or model

Call `run_episode` with an adapter, a model implementing `generate(call) -> ModelReply`, and a program directory. The adapter supplies public observations, actions, transitions and scoring. Use `open_program` to load a released version, or supply an exported directory. `evovim demo` runs the starting scaffold on the built-in grid. [Adapter interface](visual_rsi/adapters/base.py) · [Working example](visual_rsi/demo.py) · [Episode runner](visual_rsi/host/episode.py)

```python
from visual_rsi.host.episode import run_episode
from visual_rsi.programs import open_program

with open_program("gpt/card-matching") as program:
    result = run_episode(adapter, program, line="M", seed=47, model=model, archive="runs/custom")
```

## Verify the installation

```sh
python -m unittest discover -s tests -v
```

The offline suite checks program hashes, visual retrieval, the benchmark subprocess and a full local campaign with candidate selection, held-out evaluation and interrupted-run recovery. The model and revision services use scripted replies in these tests. The starting scaffold derives from AutoMem revision `1987b8f6d202212ec3c0c78ab2a01ae02aca4e8b`. [Upstream AutoMem](https://github.com/autoLearnMem/AutoMem/tree/1987b8f6d202212ec3c0c78ab2a01ae02aca4e8b)
