"""Candidate-side worker runtime."""
