"""Offline candidate replay."""

